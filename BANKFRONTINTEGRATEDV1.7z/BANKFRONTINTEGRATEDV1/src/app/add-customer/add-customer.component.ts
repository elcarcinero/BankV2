import { Component, OnInit } from '@angular/core';
import { BankContollerService } from '../bank-contoller.service';
import { Customer } from '../customer';

@Component({
  selector: 'app-add-customer',
  templateUrl: './add-customer.component.html',
  styleUrls: ['./add-customer.component.css']
})
export class AddCustomerComponent implements OnInit {
  customer = new Customer();
  constructor(private abc: BankContollerService) {
  }
  ngOnInit() {
  }
hello() {
  this.abc.hello();
}
addCustomer(fname: string, lname: string, mname: string, age: string, flatno: string, streetNo: string, city: string, state: string,phno:string) {
  this.customer.fname = fname;
  this.customer.lname = lname;
  this.customer.mname = mname;
  // tslint:disable-next-line: radix
  this.customer.age = parseInt(age);
  this.customer.flatNo = flatno;
  this.customer.street = streetNo;
  this.customer.city = city;
  this.customer.state = state;
  this.customer.phno=phno;
  console.log(this.customer);
  this.abc.createAccount(this.customer).subscribe(data=>{

  }),
  console.log('add');
}

}
