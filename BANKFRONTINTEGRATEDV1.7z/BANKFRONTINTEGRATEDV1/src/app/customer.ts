export class Customer {
  fname: string;
  lname: string;
  mname: string;
  age: number;
 flatNo: string;
 street: string;
 city: string;
state: string;
  phno: string;
}
