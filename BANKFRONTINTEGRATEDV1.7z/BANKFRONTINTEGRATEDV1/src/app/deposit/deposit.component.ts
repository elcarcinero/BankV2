import { Component, OnInit } from '@angular/core';
import { BankContollerService } from '../bank-contoller.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  constructor(private abc: BankContollerService) { }
  deposit(custId:string,Id:string,amountPass:string){
this.abc.depositAmount(custId,Id,amountPass).subscribe();
  }

  ngOnInit() {
  }

}
