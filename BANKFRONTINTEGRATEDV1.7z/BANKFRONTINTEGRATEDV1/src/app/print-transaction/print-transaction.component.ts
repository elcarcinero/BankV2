import { Component, OnInit } from '@angular/core';
import { BankContollerService } from '../bank-contoller.service';
import { strictEqual } from 'assert';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {

  str:string[];
  constructor(private abc:BankContollerService) { }
  printTransaction(id:string){
    this.abc.printTransaction(id).subscribe(
      data=> {
        this.str=data;
      }
    );
  }
  ngOnInit() {
  }

}
