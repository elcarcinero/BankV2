import { Component, OnInit } from '@angular/core';
import { BankContollerService } from '../bank-contoller.service';

@Component({
  selector: 'app-add-account',
  templateUrl: './add-account.component.html',
  styleUrls: ['./add-account.component.css']
})
export class AddAccountComponent implements OnInit {

  constructor(private abc: BankContollerService) { }

  addAccount(cid:string){
  this.abc.addAccount(cid).subscribe();
  }
  ngOnInit() {
  }

}
