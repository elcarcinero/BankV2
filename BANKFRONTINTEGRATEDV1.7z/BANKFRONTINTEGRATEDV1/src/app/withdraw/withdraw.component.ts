import { Component, OnInit } from '@angular/core';
import { BankContollerService } from '../bank-contoller.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  constructor(private abc:BankContollerService) { }
  withdraw(custId:string,Id:string,amountPass:string){
    this.abc.withdrawAmount(custId,Id,amountPass).subscribe();
      }
  ngOnInit() {
  }

}
