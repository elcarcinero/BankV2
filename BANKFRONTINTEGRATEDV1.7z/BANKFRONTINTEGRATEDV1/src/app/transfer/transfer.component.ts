import { Component, OnInit } from '@angular/core';
import { BankContollerService } from '../bank-contoller.service';

@Component({
  selector: 'app-transfer',
  templateUrl: './transfer.component.html',
  styleUrls: ['./transfer.component.css']
})
export class TransferComponent implements OnInit {

  constructor(private abc: BankContollerService) { }
  transfer(cid:string,caid:string,rid:string,raid:string,amount:string){
this.abc.transfer(cid,caid,rid,raid,amount).subscribe();

  }

  ngOnInit() {
  }

}
