import { TestBed } from '@angular/core/testing';

import { BankContollerService } from './bank-contoller.service';

describe('BankContollerService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BankContollerService = TestBed.get(BankContollerService);
    expect(service).toBeTruthy();
  });
});
