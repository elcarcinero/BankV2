import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {HttpClient,HttpClientModule} from '@angular/common/http';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { AddCustomerComponent } from './add-customer/add-customer.component';
import { TransferComponent } from './transfer/transfer.component';
import { AddAccountComponent } from './add-account/add-account.component';
import { LoginComponent } from './login/login.component';
import { PrintTransactionComponent } from './print-transaction/print-transaction.component';

@NgModule({
  declarations: [
    AppComponent,
    DepositComponent,
    WithdrawComponent,
    AddCustomerComponent,
    TransferComponent,
    AddAccountComponent,
    LoginComponent,
    PrintTransactionComponent,


  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
