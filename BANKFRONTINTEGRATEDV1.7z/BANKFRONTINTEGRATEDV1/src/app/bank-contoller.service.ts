import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Customer } from './customer';
@Injectable({
  providedIn: 'root'
})
export class BankContollerService {
  constructor(private httpClient: HttpClient) { }
  private url = 'http://localhost:6963/XYZbank';
  hello() {
    console.log('hello');
  }
  public createAccount(customer: Customer): Observable<Customer> {
    return this.httpClient.post<Customer>(this.url + "/add", customer);
    }
    public depositAmount(custId: string , id : string  , amount : string  ) : Observable<Customer>{
      //console.log("B");
      return this.httpClient.put<Customer>(this.url + '/deposit/' + custId + "/" + id + "/" + amount,"");
    }
    public withdrawAmount(custId: string , id : string  , amount : string  ) : Observable<Customer>{
      //console.log("B");
      return this.httpClient.put<Customer>(this.url + '/withdraw/' + custId + "/" + id + "/" + amount,"");
    }
    public transfer(custId: string , caid : string, rid : string , raid : string  , amount : string  ) : Observable<Customer>{
      //console.log("B");
      return this.httpClient.put<Customer>(this.url + '/transfer/' + custId + "/" + rid+ "/" + caid+ "/" + raid+ "/" + amount,"");
    }
    public addAccount(custId:string):  Observable<Customer>{
      return this.httpClient.post<Customer>("http://localhost:6961/XYZBank/addAccount/"+custId, "");

    }
    public printTransaction(custId:string):Observable<string[]>{
      return this.httpClient.get<string[]>(this.url+"/printTransaction/"+custId);
    }
}
