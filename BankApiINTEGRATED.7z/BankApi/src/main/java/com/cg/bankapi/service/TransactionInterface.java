package com.cg.bankapi.service;

import java.util.List;

import com.cg.bankapi.bean.*;

public interface TransactionInterface {
	public void addTransaction(Transaction transaction);
	//public List<Transaction>getTransactionById();
    public List<Transaction>getAllTransactions();
}
