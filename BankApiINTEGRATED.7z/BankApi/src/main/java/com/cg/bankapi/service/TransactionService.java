package com.cg.bankapi.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapi.bean.*;
import com.cg.bankapi.dao.TransactionRepository;
@Service
public class TransactionService implements TransactionInterface{
@Autowired
TransactionRepository repository;
	@Override
	public void addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		repository.save(transaction);
		
}
//	public List<Transaction> getTransactionById() {
//		// TODO Auto-generated method stub
//		return repository.getTransactionsForCustomerById();
//	}
	@Override
	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
