package com.cg.bankapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapi.bean.Account;
import com.cg.bankapi.dao.AccountRepository;
@Service
public class AccountService implements AccountInterface {
	@Autowired
	AccountRepository repository;
	@Override
	public void addAccount(Account account) {
		// TODO Auto-generated method stub
		repository.save(account);
	}
	@Override
	public List<Account> getAccounts() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}
	@Override
	public Account getAccountById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}
	@Override
	public void updateAccount(Account account) {
		// TODO Auto-generated method stub
		repository.save(account);
	}
	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}
	

}
