package com.cg.bankapi.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bankapi.bean.Account;
import com.cg.bankapi.bean.Customer;
import com.cg.bankapi.bean.Transaction;
import com.cg.bankapi.service.AccountInterface;

import com.cg.bankapi.service.CustomerInterface;
import com.cg.bankapi.service.TransactionInterface;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class BankController {
	@Autowired
	AccountInterface accountService;
	@Autowired
	CustomerInterface customerService;
	@Autowired
	TransactionInterface transactionService;
	
	@RequestMapping(value="/XYZbank/addCustomer",method=RequestMethod.POST)
	public ResponseEntity<String> addCustomer(@RequestBody Customer customer){
		customerService.addCustomer(customer);
		return new ResponseEntity<String>("Added customer",HttpStatus.OK);
		
	}
	@RequestMapping("/XYZbank/getCustomer")
	public List<Customer> getCustomer(){
		return  customerService.getAllCustomer();
		
	}
	@RequestMapping(value="/XYZbank/getCustomer",method=RequestMethod.POST)
	public void addAccount(@RequestBody Account account) {
		accountService.addAccount(account);
	}
	
	
	@RequestMapping(value="XYZbank/add" ,method = RequestMethod.POST)
	public ResponseEntity<String> myAdd(@RequestBody Customer cust) {
		Customer customer = cust;
		Account account=new Account();
		Transaction trans = new Transaction();
		customer.setUsername(customer.getFname()+"@XYZbank.com");
		customer.setPassword("PASS"+customer.getFname());
		account.setBalance(0);
		trans.setTransaction("Account Created");
        transactionService.addTransaction(trans);
         accountService.addAccount(account);
		account.setCustomer(customer);
		trans.setCustomer(customer);
		List<Transaction> a = new ArrayList<Transaction>();
		a.add(trans);
		customer.setTransactions(a);
		List<Account> ab = new ArrayList<Account>();
		ab.add(account);
		customer.setAccount(ab);
		customerService.addCustomer(customer);
		return new ResponseEntity<String>("account created",HttpStatus.OK);
	}
	@RequestMapping(value="XYZbank/deposit/{custId}/{id}/{amount}",method = RequestMethod.PUT)
	public void depositAmount(@PathVariable int custId , @PathVariable int id , @PathVariable double amount) {
		Account account=accountService.getAccountById(id);
		account.setBalance(account.getBalance()+amount);
		Transaction transaction = new Transaction();
		transaction.setTransaction("Deposit amount"+ amount + "Current Balance = "+account.getBalance());
		Customer customer = customerService.getCustomerById(custId);
		transactionService.addTransaction(transaction);
		accountService.updateAccount(account);
		transaction.setCustomer(customer);
		List<Transaction> a = new ArrayList<Transaction>();
		a.add(transaction);
		customer.setTransactions(a);
		List<Account> ab = new ArrayList<Account>();
		ab.add(account);
		customer.setAccount(ab);
		customerService.addCustomer(customer);
	}
	@RequestMapping(value="XYZbank/withdraw/{custId}/{id}/{amount}",method = RequestMethod.PUT)
	public void withdrawAmount(@PathVariable int custId , @PathVariable int id , @PathVariable double amount) {
		Account account=accountService.getAccountById(id);
		account.setBalance(account.getBalance()-amount);
		Transaction transaction = new Transaction();
		transaction.setTransaction("Withdrew amount"+ amount + "Current Balance = "+account.getBalance());
		Customer customer = customerService.getCustomerById(custId);
		transactionService.addTransaction(transaction);
		accountService.updateAccount(account);
		transaction.setCustomer(customer);
		List<Transaction> a = new ArrayList<Transaction>();
		a.add(transaction);
		customer.setTransactions(a);
		List<Account> ab = new ArrayList<Account>();
		ab.add(account);
		customer.setAccount(ab);
		customerService.addCustomer(customer);
		
		
		
	}
//	@RequestMapping(value="XYZbank/printTransactions")
//	public List<Transaction> printTransactions(){
//		return transactionService.getAllTransactions();
//		
//	}
//	
	@RequestMapping(value="XYZbank/transfer/{senderId}/{recieverId}/{accountSId}/{accountRId}/{amount}",method=RequestMethod.PUT)
	public void transfer(@PathVariable int senderId,@PathVariable int  recieverId,@PathVariable int accountSId ,@PathVariable int accountRId ,@PathVariable double amount) {
		Customer sender = customerService.getCustomerById(senderId);
		Customer reciever = customerService.getCustomerById(recieverId);
		Account accountSender = accountService.getAccountById(accountSId);
		Account accountReciever = accountService.getAccountById(accountRId);
		
		accountSender.setBalance(accountSender.getBalance()-amount);
		Transaction transactionSender= new Transaction();
		transactionSender.setTransaction("You transferred "+ amount + " To " + reciever.getFname() +" With account number " + accountRId + "Your balance is "+ accountSender.getBalance());
		accountReciever.setBalance(accountReciever.getBalance()+amount);
		Transaction transactionReciever= new Transaction();
		transactionReciever.setTransaction("You have recieved "+ amount + "from " + sender.getFname() +" from account number " + accountRId + "Your balance is "+ accountReciever.getBalance());
		
		accountService.updateAccount(accountReciever);
		accountService.updateAccount(accountSender);
		transactionService.addTransaction(transactionSender);
		transactionService.addTransaction(transactionReciever);
		
		transactionSender.setCustomer(sender);
		transactionReciever.setCustomer(reciever);
		accountSender.setCustomer(sender);
		accountReciever.setCustomer(reciever);
		List<Transaction> a = new ArrayList<Transaction>();
		a.add(transactionSender);
		sender.setTransactions(a);
		
		List<Transaction> b = new ArrayList<Transaction>();
		b.add(transactionReciever);
		sender.setTransactions(b);
		
		List<Account> ab1 = new ArrayList<Account>();
		ab1.add(accountSender);
		sender.setAccount(ab1);
		customerService.updateCustomer(sender);
		
		List<Account> ab2 = new ArrayList<Account>();
		ab2.add(accountReciever);
		reciever.setAccount(ab2);
		customerService.updateCustomer(reciever);
	}
	@RequestMapping(value="XYZBank/addAccount/{custId}",method = RequestMethod.POST)
	public void addAccount(@PathVariable int custId) {
		Customer customer = customerService.getCustomerById(custId);
		Account account = new Account();
		Transaction transaction = new Transaction();
		transaction.setTransaction("Account Created");
		account.setBalance(0);
		transactionService.addTransaction(transaction);
		accountService.addAccount(account);
		transaction.setCustomer(customer);
		account.setCustomer(customer);
		
		List<Transaction> a = new ArrayList<Transaction>();
		a.add(transaction);
		customer.setTransactions(a);
		List<Account> ab = new ArrayList<Account>();
		ab.add(account);
		customer.setAccount(ab);
		customerService.addCustomer(customer);
	}
	@RequestMapping("/XYZbank/printTransaction/{custID}")
	public List<String> login(@PathVariable int custID){
		List<Transaction> transactions = transactionService.getAllTransactions();
		List <String> transactionAns=new ArrayList<>();
		Customer customer = customerService.getCustomerById(custID);
		for(int i=0;i<transactions.size();i++) {
			if(custID==transactions.get(i).getCustomer().getId())
			{
			transactionAns.add(transactions.get(i).toString());
			}
		}
		return transactionAns;
		
	}
	
}
