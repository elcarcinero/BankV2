package com.cg.bankapi.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bankapi.bean.Account;
import com.cg.bankapi.bean.Customer;
import com.cg.bankapi.dao.AccountRepository;
import com.cg.bankapi.dao.CustomerRepository;
@Service
public class CustomerService implements CustomerInterface {
	@Autowired
	CustomerRepository repository;
	@Autowired
	AccountRepository ar;
	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		repository.save(customer);
		
	}
	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}
	@Override
	public Customer getCustomerById(int id) {
		// TODO Auto-generated method stub
		return repository.findById(id).get();
	}
	@Override
	public void updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		repository.save(customer);
	}
	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		repository.deleteById(id);
	}

}
