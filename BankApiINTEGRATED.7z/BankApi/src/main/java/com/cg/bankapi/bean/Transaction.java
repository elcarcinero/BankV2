package com.cg.bankapi.bean;

import javax.persistence.*;

import org.springframework.data.annotation.ReadOnlyProperty;

@Entity
@Table(name="Transaction_NEW")
public class Transaction {
	@Override
	public String toString() {
		return "Transaction [id=" + id + ", transaction=" + transaction + ", customer=" + customer.getFname() + "]";
	}
	@Id
	@GeneratedValue
	@ReadOnlyProperty
	private int id;
	String transaction;

	@ManyToOne
	@JoinColumn(name = "custId")
	Customer customer;
	
	
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTransaction() {
		return transaction;
	}
	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}
	
}
