package com.cg.bankapi.service;

import java.util.List;

import com.cg.bankapi.bean.Account;
import com.cg.bankapi.bean.Customer;

public interface CustomerInterface {
public void addCustomer(Customer customer);
public List<Customer> getAllCustomer();
public Customer getCustomerById(int id);
public void updateCustomer(Customer customer);
public void deleteById(int id);
}
