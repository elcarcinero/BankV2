package com.cg.bankapi.service;

import java.util.List;

import org.springframework.data.repository.query.Param;

import com.cg.bankapi.bean.Account;

public interface AccountInterface {
public void addAccount(Account account);
public List<Account> getAccounts();
public Account getAccountById(int id);
public void updateAccount(Account account);
public void deleteById(int id);
}
